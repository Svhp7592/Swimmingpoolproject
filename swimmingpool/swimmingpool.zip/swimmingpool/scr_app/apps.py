from django.apps import AppConfig


class ScrAppConfig(AppConfig):
    name = 'scr_app'
